<?php
namespace Magelearn\Customform\Model\ResourceModel\Extension;

class Collection extends \Magento\Framework\Model\ResourceModel\Db\Collection\AbstractCollection
{
	/**
     * @var string
     */
    protected $_idFieldName = 'id';
    /**
     * Define resource model.
     */

    protected function _construct()
    {
        $this->_init('\Magelearn\Customform\Model\Extension', '\Magelearn\Customform\Model\ResourceModel\Extension');
        parent::_construct();
    }
}
